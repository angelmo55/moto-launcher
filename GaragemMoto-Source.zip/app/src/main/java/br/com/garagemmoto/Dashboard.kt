package br.com.garagemmoto

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun DashboardScreen(act: MainActivity, go: (Screen) -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    // mantém a tela acesa enquanto o painel está aberto
    val view = LocalView.current
    androidx.compose.runtime.DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    val bike = Repo.selectedBike()
    val cat = bike?.catalogId?.let { Catalog.byId(it) }
    val img by produceState<LoadedImage?>(null, bike?.id, bike?.customPhoto, cat?.id) {
        value = withContext(Dispatchers.IO) { loadImage(ctx, bike, cat) }
    }

    val motion = Repo.settings.motion
    var preview by remember { mutableStateOf(false) }
    var previewSpeed by remember { mutableFloatStateOf(60f) }
    var roadPhase by remember { mutableFloatStateOf(0f) }
    var spin by remember { mutableFloatStateOf(0f) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(500)
        }
    }

    val gpsFresh = LocationEngine.lastFixMs > 0 && now - LocationEngine.lastFixMs < 5000
    val shownSpeed: Double = if (preview) previewSpeed.toDouble() else if (gpsFresh) LocationEngine.speedKmh else 0.0
    val effSpeed by rememberUpdatedState(if (motion) shownSpeed else 0.0)

    // Animação: só consome frames enquanto há movimento; para ao parar ou perder o sinal.
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            if (effSpeed < 0.5) {
                last = 0L
                delay(200)
            } else {
                androidx.compose.runtime.withFrameNanos { t ->
                    if (last != 0L) {
                        val dt = ((t - last) / 1_000_000_000f).coerceAtMost(0.1f)
                        roadPhase = (roadPhase + effSpeed.toFloat() * dt * 0.022f) % 1f
                        spin = (spin + effSpeed.toFloat() * dt * 6f) % 360f
                    }
                    last = t
                }
            }
        }
    }

    val stats = if (bike != null) computeFuel(Repo.fills.filter { it.bikeId == bike.id }) else null
    val tripKm = LocationEngine.tripDistanceM / 1000.0
    val tripActive = LocationEngine.tripState != TripState.IDLE

    val gauge: @Composable (Modifier) -> Unit = { m -> SpeedGauge(shownSpeed, m) }
    val tripCard: @Composable (Modifier) -> Unit = { m ->
        InfoCard("VIAGEM", f1(tripKm), "km", if (tripActive) "em andamento" else "sem viagem ativa", m)
    }
    val fuelCard: @Composable (Modifier) -> Unit = { m ->
        InfoCard(
            "CONSUMO MÉDIO", stats?.avgKmL?.let { f1(it) } ?: "—", "km/L",
            if (stats?.avgKmL == null) "sem dados" else "entre abastecimentos", m,
        )
    }
    val stage: @Composable (Modifier) -> Unit = { m ->
        Stage(m, img, { roadPhase }, { spin })
    }
    val buttons: @Composable () -> Unit = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("🗺️", "Maps", Modifier.weight(1f)) { openMaps(act) }
                BigButton("🎵", "Música", Modifier.weight(1f)) { openMusic(act) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BigButton("⏱️", "Viagem", Modifier.weight(1f)) { go(Screen.Trips) }
                BigButton("🏍️", "Minha Garagem", Modifier.weight(1f)) { go(Screen.Garage) }
            }
        }
    }
    val previewRow: @Composable () -> Unit = {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = preview, onCheckedChange = { preview = it })
                Spacer(Modifier.width(8.dp))
                Text("Prévia da animação", color = p.text, fontSize = 14.sp)
                Spacer(Modifier.weight(1f))
                Text(
                    if (motion) "Movimento: ligado" else "Movimento: desligado",
                    color = if (motion) p.accent else p.danger, fontSize = 12.sp,
                    modifier = Modifier.clickable { Repo.setSettings(Repo.settings.copy(motion = !motion)) }.padding(6.dp),
                )
            }
            if (preview) {
                Slider(value = previewSpeed, onValueChange = { previewSpeed = it }, valueRange = 0f..140f)
                Text("Velocidade simulada: ${previewSpeed.roundToInt()} km/h", color = p.sub, fontSize = 12.sp)
            }
        }
    }
    val header: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(bike?.name ?: "Nenhuma moto selecionada", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                val sub = when {
                    bike == null -> "Abra Minha Garagem para escolher uma moto"
                    !Perm.granted -> "Localização desativada"
                    preview -> "Prévia da animação"
                    !gpsFresh -> "Sem sinal de GPS"
                    else -> "GPS ativo"
                }
                Text(sub, color = if (Perm.granted) p.sub else p.danger, fontSize = 12.sp)
            }
            if (!Perm.granted) TextButton(onClick = { act.askPermissions() }) { Text("Ativar GPS", color = p.accent) }
            TextButton(onClick = { go(Screen.Settings) }) { Text("⚙ Ajustes", color = p.accent) }
        }
    }

    Box(Modifier.fillMaxSize().background(p.bg).safeDrawingPadding().padding(12.dp)) {
        if (!landscape) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                header()
                Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(p.panel)) {
                    stage(Modifier.fillMaxSize())
                    gauge(Modifier.align(Alignment.TopCenter).padding(top = 6.dp).size(170.dp))
                    tripCard(Modifier.align(Alignment.BottomStart).padding(10.dp).width(140.dp))
                    fuelCard(Modifier.align(Alignment.BottomEnd).padding(10.dp).width(140.dp))
                }
                previewRow()
                buttons()
            }
        } else {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.width(190.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                    gauge(Modifier.size(180.dp).align(Alignment.CenterHorizontally))
                    tripCard(Modifier.fillMaxWidth())
                    fuelCard(Modifier.fillMaxWidth())
                }
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    header()
                    Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(p.panel)) {
                        stage(Modifier.fillMaxSize())
                    }
                }
                Column(Modifier.width(250.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                    buttons()
                    previewRow()
                }
            }
        }
    }
}

// ---------------------------------------------------------------- componentes

@Composable
fun SpeedGauge(speed: Double, modifier: Modifier) {
    val p = LocalPalette.current
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = size.minDimension * 0.07f
            val d = size.minDimension - stroke
            val tl = Offset((size.width - d) / 2f, (size.height - d) / 2f)
            drawArc(p.sub.copy(alpha = 0.25f), 135f, 270f, false, tl, Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
            val sweep = 270f * (speed / 180.0).coerceIn(0.0, 1.0).toFloat()
            if (sweep > 0f) drawArc(p.accent, 135f, sweep, false, tl, Size(d, d), style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(speed.roundToInt().toString(), color = p.text, fontSize = 52.sp, fontWeight = FontWeight.Bold)
            Text("km/h", color = p.sub, fontSize = 14.sp)
        }
    }
}

@Composable
fun InfoCard(label: String, value: String, unit: String, caption: String, modifier: Modifier) {
    val p = LocalPalette.current
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(p.bg.copy(alpha = 0.85f)).padding(12.dp),
    ) {
        Text(label, color = p.sub, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(4.dp))
            Text(unit, color = p.accent, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
        Text(caption, color = p.sub, fontSize = 11.sp)
    }
}

@Composable
fun BigButton(emoji: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPalette.current
    Column(
        modifier.height(84.dp).clip(RoundedCornerShape(20.dp)).background(p.panel).clickable { onClick() }.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(emoji, fontSize = 26.sp)
        Text(label, color = p.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- palco (estrada + moto)

@Composable
fun Stage(modifier: Modifier, img: LoadedImage?, roadPhase: () -> Float, spin: () -> Float) {
    val p = LocalPalette.current
    Canvas(modifier) {
        val ph = roadPhase()
        drawRoad(p, ph)
        val image = img?.bitmap
        if (image != null) drawPhotoBike(image, img?.wheels, p, spin())
        else drawSilhouette(p, spin())
    }
}

private fun DrawScope.drawRoad(p: GPalette, phase: Float) {
    val w = size.width
    val h = size.height
    val vx = w * 0.5f
    val vy = h * 0.30f
    val farHalf = w * 0.04f
    val nearHalf = w * 0.55f

    val road = Path().apply {
        moveTo(vx - farHalf, vy)
        lineTo(vx + farHalf, vy)
        lineTo(w * 1.05f, h)
        lineTo(-w * 0.05f, h)
        close()
    }
    drawPath(road, Brush.verticalGradient(listOf(p.road.copy(alpha = 0f), p.road), startY = vy, endY = h))

    // bordas da pista
    for (side in listOf(-1f, 1f)) {
        drawLine(
            p.line.copy(alpha = 0.45f), Offset(vx + side * farHalf, vy), Offset(vx + side * nearHalf, h),
            strokeWidth = 4f,
        )
    }

    // faixas tracejadas que vêm em direção ao observador (perspectiva: y = vy + (h - vy) * t²)
    val n = 10
    for (i in 0 until n) {
        val t0 = (i + phase) / n
        val t1 = t0 + 0.5f / n
        if (t1 > 1f) continue
        val f0 = t0 * t0
        val f1 = t1 * t1
        val y0 = vy + (h - vy) * f0
        val y1 = vy + (h - vy) * f1
        val half0 = farHalf + (nearHalf - farHalf) * f0
        val half1 = farHalf + (nearHalf - farHalf) * f1
        for (lane in listOf(-0.34f, 0.34f)) {
            drawLine(
                p.line.copy(alpha = (0.15f + 0.6f * f1).coerceAtMost(0.8f)),
                Offset(vx + lane * half0, y0), Offset(vx + lane * half1, y1),
                strokeWidth = 2f + 12f * f1, cap = StrokeCap.Butt,
            )
        }
    }
}

private fun DrawScope.drawPhotoBike(image: androidx.compose.ui.graphics.ImageBitmap, wheels: FloatArray?, p: GPalette, spin: Float) {
    val w = size.width
    val h = size.height
    val iw = image.width
    val ih = image.height
    val sc = min(w * 0.9f / iw, h * 0.58f / ih)
    val dw = (iw * sc).toInt()
    val dh = (ih * sc).toInt()
    val left = ((w - dw) / 2f).toInt()
    val top = (h * 0.92f - dh).toInt()
    drawOval(Color.Black.copy(alpha = 0.35f), Offset(left + dw * 0.08f, top + dh * 0.86f), Size(dw * 0.84f, dh * 0.14f))
    drawImage(image, dstOffset = IntOffset(left, top), dstSize = IntSize(dw, dh))
    // Rodas girando só quando a foto traz as âncoras das rodas. Foto própria: só o efeito de estrada.
    if (wheels != null) {
        val tire = if (p.dark) Color(0xFF111111) else Color(0xFF222222)
        drawWheel(Offset(left + wheels[0] * dw, top + wheels[1] * dh), wheels[2] * dw, 0.62f, spin, tire, solid = true)
        drawWheel(Offset(left + wheels[3] * dw, top + wheels[4] * dh), wheels[5] * dw, 0.62f, spin, tire, solid = true)
    }
}

/** Ilustração de reserva (sem foto): moto em traços, com rodas elípticas girando em perspectiva. */
private fun DrawScope.drawSilhouette(p: GPalette, spin: Float) {
    val w = size.width
    val h = size.height
    val bw = w * 0.9f
    val bh = h * 0.5f
    val s = min(bw / 1000f, bh / 600f)
    val ox = (w - 1000f * s) / 2f
    val oy = h * 0.92f - 600f * s
    fun x(v: Float) = ox + v * s
    fun y(v: Float) = oy + v * s
    val dark = if (p.dark) Color(0xFFCBD5E1) else Color(0xFF1F2937)

    drawOval(Color.Black.copy(alpha = 0.3f), Offset(x(120f), y(520f)), Size(780f * s, 70f * s))
    drawWheel(Offset(x(240f), y(430f)), 125f * s, 0.62f, spin, dark, solid = false)
    drawWheel(Offset(x(770f), y(430f)), 125f * s, 0.62f, spin, dark, solid = false)

    val frame = Path().apply {
        moveTo(x(240f), y(430f)); lineTo(x(400f), y(300f)); lineTo(x(560f), y(300f))
        lineTo(x(700f), y(250f)); lineTo(x(770f), y(430f))
    }
    drawPath(frame, dark, style = Stroke(width = 14f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
    val tank = Path().apply {
        moveTo(x(430f), y(290f))
        cubicTo(x(470f), y(220f), x(600f), y(210f), x(660f), y(260f))
        lineTo(x(600f), y(310f)); close()
    }
    drawPath(tank, p.accent)
    drawRoundRect(dark, Offset(x(280f), y(280f)), Size(190f * s, 36f * s), CornerRadius(18f * s))
    drawRoundRect(dark.copy(alpha = 0.85f), Offset(x(400f), y(330f)), Size(170f * s, 90f * s), CornerRadius(14f * s))
    drawLine(dark, Offset(x(690f), y(235f)), Offset(x(730f), y(190f)), strokeWidth = 10f * s, cap = StrokeCap.Round)
    drawCircle(Color(0xFFFFE08A), 20f * s, Offset(x(735f), y(270f)))
}

/** Roda em perspectiva: círculo achatado no eixo X (elipse) com raios que giram. */
private fun DrawScope.drawWheel(c: Offset, r: Float, squash: Float, angle: Float, col: Color, solid: Boolean) {
    withTransform({ scale(squash, 1f, pivot = c) }) {
        if (solid) drawCircle(col.copy(alpha = 0.55f), r, c)
        drawCircle(col, r, c, style = Stroke(width = r * 0.28f))
        drawCircle(col.copy(alpha = 0.5f), r * 0.62f, c, style = Stroke(width = r * 0.06f))
        rotate(angle, c) {
            for (i in 0 until 6) {
                val rad = (i * 60.0) * PI / 180.0
                drawLine(
                    col, c, Offset(c.x + (r * 0.7f * cos(rad)).toFloat(), c.y + (r * 0.7f * sin(rad)).toFloat()),
                    strokeWidth = r * 0.05f,
                )
            }
        }
    }
}
