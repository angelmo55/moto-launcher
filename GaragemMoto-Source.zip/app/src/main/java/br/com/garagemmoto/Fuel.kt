package br.com.garagemmoto

data class Segment(val end: Fill, val km: Double, val liters: Double, val kmL: Double, val cost: Double)

data class FuelStats(
    val avgKmL: Double?,
    val lastKmL: Double?,
    val costPerKm: Double?,
    val segments: List<Segment>,
    val message: String?,
)

/**
 * km/L só é calculado entre dois abastecimentos com tanque cheio.
 * Os litros dos abastecimentos parciais entre eles entram na conta.
 */
fun computeFuel(all: List<Fill>): FuelStats {
    val sorted = all.sortedBy { it.odometerKm }
    val fullCount = sorted.count { it.full }
    if (fullCount < 2) {
        return FuelStats(
            null, null, null, emptyList(),
            "Faltam dados: registre pelo menos dois abastecimentos com tanque cheio para calcular o km/L.",
        )
    }
    val segs = mutableListOf<Segment>()
    var prevFull: Fill? = null
    var litersAcc = 0.0
    var costAcc = 0.0
    for (f in sorted) {
        val pf = prevFull
        if (pf != null) {
            litersAcc += f.liters
            costAcc += f.liters * f.pricePerLiter
        }
        if (f.full) {
            if (pf != null) {
                val km = f.odometerKm - pf.odometerKm
                if (km > 0 && litersAcc > 0) segs.add(Segment(f, km, litersAcc, km / litersAcc, costAcc))
            }
            prevFull = f
            litersAcc = 0.0
            costAcc = 0.0
        }
    }
    if (segs.isEmpty()) {
        return FuelStats(
            null, null, null, emptyList(),
            "Os dados estão inconsistentes: confira se o odômetro aumenta a cada abastecimento.",
        )
    }
    val km = segs.sumOf { it.km }
    val lit = segs.sumOf { it.liters }
    val cost = segs.sumOf { it.cost }
    return FuelStats(km / lit, segs.last().kmL, cost / km, segs, null)
}
