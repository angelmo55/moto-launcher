package br.com.garagemmoto

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.max

val PT: Locale = Locale.forLanguageTag("pt-BR")

fun f1(d: Double): String = String.format(PT, "%.1f", d)
fun f2(d: Double): String = String.format(PT, "%.2f", d)
fun money(d: Double): String = NumberFormat.getCurrencyInstance(PT).format(d)
fun parseD(s: String): Double? = s.trim().replace(',', '.').toDoubleOrNull()
fun dateFmt(ms: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", PT).format(Date(ms))
fun durFmt(ms: Long): String {
    val s = ms / 1000
    return String.format(PT, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
fun newId(): String = UUID.randomUUID().toString()

class LoadedImage(val bitmap: ImageBitmap?, val wheels: FloatArray?, val custom: Boolean)

/** Foto própria (só efeito de estrada) > foto do catálogo (com rodas, se houver âncoras) > nenhuma. */
fun loadImage(ctx: Context, bike: Bike?, cat: CatalogBike?): LoadedImage {
    val custom = bike?.customPhoto
    if (custom != null) {
        val f = File(custom)
        if (f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            if (bmp != null) return LoadedImage(bmp.asImageBitmap(), null, true)
        }
    }
    val photo = cat?.photo
    if (photo != null) {
        try {
            ctx.assets.open(photo).use {
                val bmp = BitmapFactory.decodeStream(it)
                if (bmp != null) return LoadedImage(bmp.asImageBitmap(), cat?.wheels, false)
            }
        } catch (_: Exception) {
        }
    }
    return LoadedImage(null, null, false)
}

/** Copia a foto da galeria para o armazenamento interno (máx. 1600 px, corrige rotação EXIF). */
fun importPhoto(ctx: Context, uri: Uri, bikeId: String): String? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null
        val orientation = ctx.contentResolver.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val deg = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val out = if (deg != 0f) {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        } else bmp
        val dir = File(ctx.filesDir, "photos").apply { mkdirs() }
        val dest = File(dir, "custom_${bikeId}_${System.currentTimeMillis()}.png")
        dest.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return dest.absolutePath
    } catch (_: Exception) {
        return null
    }
}

fun openMaps(act: Activity) {
    val waze = Repo.settings.mapApp == "waze"
    val pkg = if (waze) "com.waze" else "com.google.android.apps.maps"
    val i = act.packageManager.getLaunchIntentForPackage(pkg)
    if (i != null) act.startActivity(i)
    else Toast.makeText(act, (if (waze) "Waze" else "Google Maps") + " indisponível. Instale pela Play Store.", Toast.LENGTH_LONG).show()
}

fun openMusic(act: Activity) {
    val pkg = Repo.settings.musicPkg
    if (pkg != null) {
        val i = act.packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            act.startActivity(i)
            return
        }
    }
    try {
        act.startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
    } catch (_: Exception) {
        Toast.makeText(act, "Nenhum player de música encontrado.", Toast.LENGTH_LONG).show()
    }
}

/** Pares (pacote, nome) de players de música instalados. */
fun musicApps(ctx: Context): List<Pair<String, String>> {
    val pm = ctx.packageManager
    val map = linkedMapOf<String, String>()
    try {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
        pm.queryIntentActivities(q, 0).forEach { map[it.activityInfo.packageName] = it.loadLabel(pm).toString() }
    } catch (_: Exception) {
    }
    listOf("com.spotify.music", "com.google.android.apps.youtube.music", "deezer.android.app", "com.amazon.mp3")
        .forEach { pkg ->
            if (pkg !in map && pm.getLaunchIntentForPackage(pkg) != null) {
                try {
                    map[pkg] = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
                } catch (_: Exception) {
                }
            }
        }
    return map.toList()
}

fun exportData(ctx: Context) {
    try {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        val files = listOf(
            File(dir, "garagem-moto-$stamp.json").apply { writeText(Repo.exportJson()) },
            File(dir, "viagens-$stamp.csv").apply { writeText(Repo.tripsCsv()) },
            File(dir, "abastecimentos-$stamp.csv").apply { writeText(Repo.fillsCsv()) },
        )
        val uris = ArrayList<Uri>()
        files.forEach { uris.add(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", it)) }
        val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Exportar histórico").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Falha ao exportar: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
