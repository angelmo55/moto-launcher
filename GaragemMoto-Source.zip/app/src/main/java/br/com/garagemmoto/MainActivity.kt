package br.com.garagemmoto

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        Perm.refresh(this)
        if (Perm.granted) LocationEngine.acquire(this, "ui")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Repo.init(this)
        Catalog.load(this)
        Perm.refresh(this)
        setContent {
            GaragemTheme {
                App(this)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Perm.refresh(this)
        if (Perm.granted) LocationEngine.acquire(this, "ui")
    }

    override fun onStop() {
        super.onStop()
        LocationEngine.release("ui")
    }

    fun askPermissions() {
        val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(l.toTypedArray())
    }
}

@Composable
private fun App(act: MainActivity) {
    var stack by remember { mutableStateOf(listOf(Screen.Dashboard)) }
    val current = stack.last()
    fun go(s: Screen) { stack = stack + s }
    fun back() { if (stack.size > 1) stack = stack.dropLast(1) }

    BackHandler(enabled = stack.size > 1) { back() }

    when (current) {
        Screen.Dashboard -> DashboardScreen(act) { go(it) }
        Screen.Garage -> GarageScreen({ go(it) }, { back() })
        Screen.Catalog -> CatalogScreen { back() }
        Screen.Trips -> TripsScreen(act) { back() }
        Screen.Fuel -> FuelScreen { back() }
        Screen.Reminders -> RemindersScreen { back() }
        Screen.Settings -> SettingsScreen(act) { back() }
    }
}
