package br.com.garagemmoto

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil

enum class Screen { Dashboard, Garage, Catalog, Trips, Fuel, Reminders, Settings }

// ---------------------------------------------------------------- base

@Composable
fun ScreenFrame(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Column(Modifier.fillMaxSize().background(p.bg).safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Voltar", color = p.accent) }
            Spacer(Modifier.width(4.dp))
            Text(title, color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        content()
    }
}

@Composable
private fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.panel).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        content = content,
    )
}

@Composable
private fun numField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = modifier,
    )
}

// ---------------------------------------------------------------- Minha Garagem

@Composable
fun GarageScreen(go: (Screen) -> Unit, back: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var photoTarget by remember { mutableStateOf<String?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var editOdo by remember { mutableStateOf<Bike?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val id = photoTarget
        if (uri != null && id != null) {
            scope.launch {
                val path = withContext(Dispatchers.IO) { importPhoto(ctx, uri, id) }
                val b = Repo.bikes.firstOrNull { it.id == id }
                if (path != null && b != null) {
                    b.customPhoto?.let { File(it).delete() }
                    Repo.updateBike(b.copy(customPhoto = path))
                    Toast.makeText(ctx, "Foto importada. Só o efeito de estrada será aplicado.", Toast.LENGTH_LONG).show()
                } else Toast.makeText(ctx, "Não foi possível importar a foto.", Toast.LENGTH_LONG).show()
            }
        }
    }

    ScreenFrame("Minha Garagem", back) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { go(Screen.Catalog) }, modifier = Modifier.weight(1f)) { Text("Catálogo") }
                    Button(onClick = { go(Screen.Fuel) }, modifier = Modifier.weight(1f)) { Text("Combustível") }
                    Button(onClick = { go(Screen.Reminders) }, modifier = Modifier.weight(1f)) { Text("Lembretes") }
                }
            }
            item {
                OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth()) { Text("＋ Moto personalizada") }
            }
            if (Repo.bikes.isEmpty()) {
                item {
                    Text(
                        "Sua garagem está vazia. Adicione uma moto pelo Catálogo ou crie uma personalizada.",
                        color = p.sub,
                    )
                }
            }
            items(Repo.bikes, key = { it.id }) { b ->
                val selected = Repo.selectedBike()?.id == b.id
                val cat = b.catalogId?.let { Catalog.byId(it) }
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selected, onClick = { Repo.setSettings(Repo.settings.copy(selectedBikeId = b.id)) })
                        Column(Modifier.weight(1f)) {
                            Text(b.name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                (if (b.year > 0) "${b.year} · " else "") + "${f1(b.odometerKm)} km" +
                                    if (selected) " · no painel" else "",
                                color = p.sub, fontSize = 12.sp,
                            )
                        }
                    }
                    val photoInfo = when {
                        b.customPhoto != null -> "Foto própria (efeito de estrada)"
                        cat?.photo != null -> "Foto do catálogo"
                        else -> "Foto pendente: importe a sua"
                    }
                    Text(photoInfo, color = if (b.customPhoto == null && cat?.photo == null) p.danger else p.sub, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = {
                            photoTarget = b.id
                            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        }) { Text("Importar foto", fontSize = 12.sp) }
                        OutlinedButton(onClick = { editOdo = b }) { Text("Odômetro", fontSize = 12.sp) }
                        TextButton(onClick = { Repo.removeBike(b.id) }) { Text("Excluir", color = p.danger, fontSize = 12.sp) }
                    }
                }
            }
        }
    }

    if (showAdd) {
        var name by remember { mutableStateOf("") }
        var year by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Moto personalizada") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nome (ex.: Minha CG 160)") }, singleLine = true)
                    numField("Ano", year, { year = it })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) {
                        Repo.addBike(Bike(newId(), null, name.trim(), year.toIntOrNull() ?: 0, null, 0.0))
                        showAdd = false
                    }
                }) { Text("Adicionar") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancelar") } },
        )
    }

    editOdo?.let { b ->
        var v by remember { mutableStateOf(f1(b.odometerKm).replace(".", "")) }
        AlertDialog(
            onDismissRequest = { editOdo = null },
            title = { Text("Odômetro de ${b.name}") },
            text = { numField("Quilometragem atual (km)", v, { v = it }) },
            confirmButton = {
                TextButton(onClick = {
                    parseD(v)?.let { Repo.updateBike(b.copy(odometerKm = it)) }
                    editOdo = null
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { editOdo = null }) { Text("Cancelar") } },
        )
    }
}

// ---------------------------------------------------------------- Catálogo

@Composable
fun CatalogScreen(back: () -> Unit) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("Todas") }
    var category by remember { mutableStateOf("Todas") }
    val all = Catalog.items
    val brands = listOf("Todas", "Favoritas") + all.map { it.brand }.distinct()
    val cats = listOf("Todas") + all.map { it.category }.distinct().sorted()

    val filtered = all.filter {
        (brand == "Todas" || (brand == "Favoritas" && it.id in Repo.favorites) || it.brand == brand) &&
            (category == "Todas" || it.category == category) &&
            (query.isBlank() || "${it.brand} ${it.model} ${it.year} ${it.category} ${it.version}".contains(query.trim(), ignoreCase = true))
    }

    ScreenFrame("Catálogo (${all.size} modelos)", back) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, label = { Text("Buscar marca, modelo, ano ou categoria") },
            singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        )
        LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp, 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(brands) { b -> FilterChip(selected = brand == b, onClick = { brand = b }, label = { Text(b) }) }
        }
        LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp, 0.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(cats) { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (filtered.isEmpty()) item { Text("Nenhum modelo encontrado.", color = p.sub) }
            var lastBrand = ""
            filtered.forEach { m ->
                if (m.brand != lastBrand) {
                    lastBrand = m.brand
                    item(key = "h-${m.brand}") { Text(m.brand.uppercase(), color = p.accent, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)) }
                }
                item(key = m.id) {
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${m.brand} ${m.model}", color = p.text, fontWeight = FontWeight.Bold)
                                Text("${m.year} · ${m.category} · versão ${m.version}", color = p.sub, fontSize = 12.sp)
                                Text(
                                    if (m.photo == null) "📷 Foto pendente (importe a sua em Minha Garagem)" else "📷 Foto com crédito registrado",
                                    color = if (m.photo == null) p.danger else p.sub, fontSize = 12.sp,
                                )
                            }
                            TextButton(onClick = { Repo.toggleFavorite(m.id) }) {
                                Text(if (m.id in Repo.favorites) "★" else "☆", fontSize = 24.sp, color = p.accent)
                            }
                        }
                        Button(onClick = {
                            Repo.addBike(Bike(newId(), m.id, "${m.brand} ${m.model}", m.year, null, 0.0))
                            Toast.makeText(ctx, "${m.model} adicionada à garagem", Toast.LENGTH_SHORT).show()
                        }) { Text("Adicionar à garagem") }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Viagem

@Composable
fun TripsScreen(act: MainActivity, back: () -> Unit) {
    val p = LocalPalette.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val state = LocationEngine.tripState
    val bike = Repo.selectedBike()
    val elapsed = LocationEngine.tripElapsedMs(now)
    val km = LocationEngine.tripDistanceM / 1000.0
    val avg = if (elapsed > 0) km / (elapsed / 3600000.0) else 0.0

    ScreenFrame("Viagem", back) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Panel {
                    Text(
                        when (state) {
                            TripState.IDLE -> "Nenhuma viagem em andamento"
                            TripState.RUNNING -> "Viagem em andamento"
                            TripState.PAUSED -> "Viagem pausada"
                        },
                        color = p.text, fontWeight = FontWeight.Bold,
                    )
                    Text("Moto: ${bike?.name ?: "nenhuma selecionada"}", color = p.sub, fontSize = 12.sp)
                    Text("${f2(km)} km · ${durFmt(elapsed)} · média ${f1(avg)} km/h", color = p.text, fontSize = 20.sp)
                    if (!Perm.granted) {
                        Text("Permita a localização precisa para registrar viagens.", color = p.danger, fontSize = 12.sp)
                        Button(onClick = { act.askPermissions() }) { Text("Permitir localização") }
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            when (state) {
                                TripState.IDLE -> Button(onClick = { LocationEngine.startTrip(act, bike?.id) }) { Text("Iniciar") }
                                TripState.RUNNING -> {
                                    OutlinedButton(onClick = { LocationEngine.pauseTrip() }) { Text("Pausar") }
                                    Button(onClick = { finish(act) }) { Text("Finalizar") }
                                }
                                TripState.PAUSED -> {
                                    Button(onClick = { LocationEngine.resumeTrip() }) { Text("Retomar") }
                                    OutlinedButton(onClick = { finish(act) }) { Text("Finalizar") }
                                }
                            }
                        }
                    }
                    if (state != TripState.IDLE) {
                        Text("O registro continua com o Maps/Waze aberto.", color = p.sub, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { openMaps(act) }) { Text("Abrir navegação") }
                        }
                    }
                }
            }
            item { Text("Histórico", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            if (Repo.trips.isEmpty()) item { Text("Nenhuma viagem registrada ainda.", color = p.sub) }
            items(Repo.trips, key = { it.id }) { t ->
                Panel {
                    Text(dateFmt(t.startMs), color = p.text, fontWeight = FontWeight.Bold)
                    Text(
                        "${f2(t.distanceM / 1000.0)} km · ${durFmt(t.durationMs)} · média ${f1(t.avgKmh)} km/h",
                        color = p.sub, fontSize = 13.sp,
                    )
                    val name = Repo.bikes.firstOrNull { it.id == t.bikeId }?.name
                    if (name != null) Text(name, color = p.sub, fontSize = 12.sp)
                    TextButton(onClick = { Repo.deleteTrip(t.id) }) { Text("Excluir", color = p.danger, fontSize = 12.sp) }
                }
            }
        }
    }
}

private fun finish(act: MainActivity) {
    val t = LocationEngine.finishTrip(act)
    if (t != null) Toast.makeText(act, "Viagem salva: ${f2(t.distanceM / 1000.0)} km", Toast.LENGTH_SHORT).show()
}

// ---------------------------------------------------------------- Combustível

@Composable
fun FuelScreen(back: () -> Unit) {
    val p = LocalPalette.current
    val bike = Repo.selectedBike()
    var odo by remember { mutableStateOf("") }
    var liters by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var full by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    ScreenFrame("Combustível", back) {
        if (bike == null) {
            Text("Escolha uma moto em Minha Garagem para registrar abastecimentos.", color = p.sub, modifier = Modifier.padding(16.dp))
            return@ScreenFrame
        }
        val fills = Repo.fills.filter { it.bikeId == bike.id }
        val stats = computeFuel(fills)
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Panel {
                    Text(bike.name, color = p.text, fontWeight = FontWeight.Bold)
                    if (stats.message != null) {
                        Text(stats.message, color = p.danger, fontSize = 13.sp)
                    } else {
                        Text("Média: ${f1(stats.avgKmL ?: 0.0)} km/L", color = p.text, fontSize = 20.sp)
                        Text("Último trecho: ${f1(stats.lastKmL ?: 0.0)} km/L", color = p.sub, fontSize = 13.sp)
                        Text("Custo: ${money(stats.costPerKm ?: 0.0)} por km", color = p.sub, fontSize = 13.sp)
                    }
                }
            }
            item {
                Panel {
                    Text("Novo abastecimento", color = p.text, fontWeight = FontWeight.Bold)
                    numField("Odômetro (km)", odo, { odo = it }, Modifier.fillMaxWidth())
                    numField("Litros", liters, { liters = it }, Modifier.fillMaxWidth())
                    numField("Preço por litro (R$)", price, { price = it }, Modifier.fillMaxWidth())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = full, onCheckedChange = { full = it })
                        Text("Tanque cheio", color = p.text)
                    }
                    error?.let { Text(it, color = p.danger, fontSize = 12.sp) }
                    Button(onClick = {
                        val o = parseD(odo)
                        val l = parseD(liters)
                        val pr = parseD(price)
                        if (o == null || l == null || pr == null || o <= 0 || l <= 0 || pr <= 0) {
                            error = "Preencha odômetro, litros e preço com valores maiores que zero."
                        } else {
                            Repo.addFill(Fill(newId(), bike.id, System.currentTimeMillis(), o, l, pr, full))
                            odo = ""; liters = ""; price = ""; error = null
                        }
                    }) { Text("Salvar") }
                }
            }
            item { Text("Histórico", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
            if (fills.isEmpty()) item { Text("Nenhum abastecimento registrado para esta moto.", color = p.sub) }
            items(fills.sortedByDescending { it.odometerKm }, key = { it.id }) { f ->
                val seg = stats.segments.firstOrNull { it.end.id == f.id }
                Panel {
                    Text("${dateFmt(f.dateMs)} · ${f1(f.odometerKm)} km", color = p.text, fontWeight = FontWeight.Bold)
                    Text(
                        "${f2(f.liters)} L × ${money(f.pricePerLiter)} = ${money(f.liters * f.pricePerLiter)}" +
                            if (f.full) " · tanque cheio" else " · parcial",
                        color = p.sub, fontSize = 13.sp,
                    )
                    if (seg != null) {
                        Text("${f1(seg.kmL)} km/L · ${money(seg.cost / seg.km)}/km neste trecho", color = p.accent, fontSize = 13.sp)
                    } else if (f.full) {
                        Text("Sem trecho anterior para calcular o km/L.", color = p.sub, fontSize = 12.sp)
                    }
                    TextButton(onClick = { Repo.deleteFill(f.id) }) { Text("Excluir", color = p.danger, fontSize = 12.sp) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Lembretes

private val REMINDER_TYPES = listOf("Troca de óleo", "Revisão", "Corrente", "Pneus")

private fun reminderStatus(r: Reminder, bike: Bike, now: Long): Pair<String, Boolean> {
    val parts = mutableListOf<String>()
    var late = false
    r.everyDays?.let {
        val due = r.lastDateMs + it * 86_400_000L
        val days = ceil((due - now) / 86_400_000.0).toInt()
        if (days < 0) { late = true; parts.add("atrasado há ${abs(days)} dias") } else parts.add("faltam $days dias")
    }
    r.everyKm?.let {
        val left = r.lastKm + it - bike.odometerKm
        if (left <= 0) { late = true; parts.add("atrasado ${f1(abs(left))} km") } else parts.add("faltam ${f1(left)} km")
    }
    return parts.joinToString(" · ") to late
}

@Composable
fun RemindersScreen(back: () -> Unit) {
    val p = LocalPalette.current
    val bike = Repo.selectedBike()
    var type by remember { mutableStateOf(REMINDER_TYPES[0]) }
    var days by remember { mutableStateOf("") }
    var kms by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    ScreenFrame("Lembretes de manutenção", back) {
        if (bike == null) {
            Text("Escolha uma moto em Minha Garagem.", color = p.sub, modifier = Modifier.padding(16.dp))
            return@ScreenFrame
        }
        val list = Repo.reminders.filter { it.bikeId == bike.id }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Panel {
                    Text("${bike.name} · ${f1(bike.odometerKm)} km", color = p.text, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(REMINDER_TYPES) { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
                    }
                    numField("A cada quantos dias (opcional)", days, { days = it }, Modifier.fillMaxWidth())
                    numField("A cada quantos km (opcional)", kms, { kms = it }, Modifier.fillMaxWidth())
                    error?.let { Text(it, color = p.danger, fontSize = 12.sp) }
                    Button(onClick = {
                        val d = days.trim().toIntOrNull()
                        val k = kms.trim().toIntOrNull()
                        if ((d == null || d <= 0) && (k == null || k <= 0)) {
                            error = "Informe um intervalo em dias, em km, ou ambos."
                        } else {
                            Repo.addReminder(
                                Reminder(newId(), bike.id, type, d?.takeIf { it > 0 }, k?.takeIf { it > 0 }, System.currentTimeMillis(), bike.odometerKm),
                            )
                            days = ""; kms = ""; error = null
                        }
                    }) { Text("Adicionar lembrete") }
                    Text("O intervalo começa a contar agora, com o odômetro atual da moto.", color = p.sub, fontSize = 11.sp)
                }
            }
            if (list.isEmpty()) item { Text("Nenhum lembrete para esta moto.", color = p.sub) }
            items(list, key = { it.id }) { r ->
                val (text, late) = reminderStatus(r, bike, System.currentTimeMillis())
                Panel {
                    Text(r.type, color = p.text, fontWeight = FontWeight.Bold)
                    Text(text, color = if (late) p.danger else p.sub, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = {
                            Repo.updateReminder(r.copy(lastDateMs = System.currentTimeMillis(), lastKm = bike.odometerKm))
                        }) { Text("Feito agora", fontSize = 12.sp) }
                        TextButton(onClick = { Repo.deleteReminder(r.id) }) { Text("Excluir", color = p.danger, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Ajustes

@Composable
fun SettingsScreen(act: MainActivity, back: () -> Unit) {
    val p = LocalPalette.current
    val s = Repo.settings
    val music = remember { musicApps(act) }

    ScreenFrame("Ajustes", back) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Panel {
                    Text("Aplicativo de navegação", color = p.text, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = s.mapApp == "google", onClick = { Repo.setSettings(s.copy(mapApp = "google")) }, label = { Text("Google Maps") })
                        FilterChip(selected = s.mapApp == "waze", onClick = { Repo.setSettings(s.copy(mapApp = "waze")) }, label = { Text("Waze") })
                    }
                }
            }
            item {
                Panel {
                    Text("Player de música", color = p.text, fontWeight = FontWeight.Bold)
                    FilterChip(selected = s.musicPkg == null, onClick = { Repo.setSettings(s.copy(musicPkg = null)) }, label = { Text("Perguntar sempre") })
                    if (music.isEmpty()) Text("Nenhum player encontrado neste aparelho.", color = p.sub, fontSize = 12.sp)
                    music.forEach { (pkg, label) ->
                        FilterChip(selected = s.musicPkg == pkg, onClick = { Repo.setSettings(s.copy(musicPkg = pkg)) }, label = { Text(label) })
                    }
                }
            }
            item {
                Panel {
                    Text("Tema", color = p.text, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("auto" to "Automático", "dia" to "Dia", "noite" to "Noite").forEach { (k, l) ->
                            FilterChip(selected = s.theme == k, onClick = { Repo.setSettings(s.copy(theme = k)) }, label = { Text(l) })
                        }
                    }
                }
            }
            item {
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Movimento da animação", color = p.text, fontWeight = FontWeight.Bold)
                            Text("Desligue para deixar estrada e rodas paradas.", color = p.sub, fontSize = 12.sp)
                        }
                        Switch(checked = s.motion, onCheckedChange = { Repo.setSettings(s.copy(motion = it)) })
                    }
                }
            }
            item {
                Panel {
                    Text("Dados", color = p.text, fontWeight = FontWeight.Bold)
                    Text("Tudo fica salvo no aparelho. Exporta JSON completo e CSV de viagens e abastecimentos.", color = p.sub, fontSize = 12.sp)
                    Button(onClick = { exportData(act) }) { Text("Exportar histórico") }
                }
            }
            item {
                Panel {
                    Text("Sobre", color = p.text, fontWeight = FontWeight.Bold)
                    Text("Garagem Moto 1.0.0 · identidade visual inspirada no Garagem TS-7.", color = p.sub, fontSize = 12.sp)
                    Text("Créditos das fotos: veja photos/CREDITS.md no projeto.", color = p.sub, fontSize = 12.sp)
                }
            }
        }
    }
}
