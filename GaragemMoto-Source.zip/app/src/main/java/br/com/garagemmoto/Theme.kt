package br.com.garagemmoto

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

data class GPalette(
    val bg: Color,
    val panel: Color,
    val text: Color,
    val sub: Color,
    val accent: Color,
    val danger: Color,
    val road: Color,
    val line: Color,
    val dark: Boolean,
)

val NightPalette = GPalette(
    bg = Color(0xFF0B0F17), panel = Color(0xFF151C29), text = Color(0xFFF2F5FA), sub = Color(0xFF93A0B4),
    accent = Color(0xFF2E9BFF), danger = Color(0xFFFF5C5C), road = Color(0xFF222B3A), line = Color(0xFFE8EEF7),
    dark = true,
)
val DayPalette = GPalette(
    bg = Color(0xFFEFF3F8), panel = Color(0xFFFFFFFF), text = Color(0xFF111827), sub = Color(0xFF5B6678),
    accent = Color(0xFF0B63CE), danger = Color(0xFFD32F2F), road = Color(0xFFB9C4D2), line = Color(0xFFFFFFFF),
    dark = false,
)

val LocalPalette = staticCompositionLocalOf { NightPalette }

@Composable
fun GaragemTheme(content: @Composable () -> Unit) {
    val dark = when (Repo.settings.theme) {
        "dia" -> false
        "noite" -> true
        else -> isSystemInDarkTheme()
    }
    val p = if (dark) NightPalette else DayPalette
    val scheme = if (dark) {
        darkColorScheme(
            primary = p.accent, onPrimary = Color.White, background = p.bg, onBackground = p.text,
            surface = p.panel, onSurface = p.text, surfaceVariant = p.panel, onSurfaceVariant = p.sub,
        )
    } else {
        lightColorScheme(
            primary = p.accent, onPrimary = Color.White, background = p.bg, onBackground = p.text,
            surface = p.panel, onSurface = p.text, surfaceVariant = p.panel, onSurfaceVariant = p.sub,
        )
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
