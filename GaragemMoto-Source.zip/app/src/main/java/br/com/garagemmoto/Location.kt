package br.com.garagemmoto

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

enum class TripState { IDLE, RUNNING, PAUSED }

/** Estado de permissão de localização precisa (GPS). */
object Perm {
    var granted by mutableStateOf(false)

    fun refresh(ctx: Context) {
        granted = ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
    }
}

/**
 * Único dono das atualizações de GPS. A tela e o serviço de viagem "adquirem" o GPS;
 * quando ninguém o usa, as atualizações são desligadas.
 */
object LocationEngine {
    var speedKmh by mutableDoubleStateOf(0.0)
        private set
    var lastFixMs by mutableLongStateOf(0L)
        private set
    var tripState by mutableStateOf(TripState.IDLE)
        private set
    var tripDistanceM by mutableDoubleStateOf(0.0)
        private set

    private var tripBikeId: String? = null
    private var tripStartMs = 0L
    private var tripAccumMs = 0L
    private var tripResumeMs = 0L
    private var lastLoc: Location? = null
    private val owners = mutableSetOf<String>()
    private var mgr: LocationManager? = null

    private val listener = object : LocationListener {
        override fun onLocationChanged(loc: Location) {
            if (loc.hasAccuracy() && loc.accuracy > 60f) return
            val now = System.currentTimeMillis()
            val prev = lastLoc
            var kmh: Double = if (loc.hasSpeed()) {
                loc.speed * 3.6
            } else if (prev != null) {
                val dt = (loc.time - prev.time) / 1000.0
                if (dt > 0) prev.distanceTo(loc) / dt * 3.6 else 0.0
            } else 0.0
            if (kmh < 2.0) kmh = 0.0
            speedKmh = kmh
            lastFixMs = now
            if (tripState == TripState.RUNNING && prev != null && kmh > 0) {
                val d = prev.distanceTo(loc)
                if (d < 2000f) tripDistanceM += d
            }
            lastLoc = loc
        }

        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
        }

        override fun onProviderEnabled(provider: String) {
        }

        override fun onProviderDisabled(provider: String) {
            speedKmh = 0.0
        }
    }

    @SuppressLint("MissingPermission")
    fun acquire(ctx: Context, owner: String) {
        val first = owners.isEmpty()
        owners.add(owner)
        if (!first) return
        try {
            val m = ctx.applicationContext.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            mgr = m
            m.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
        } catch (_: Exception) {
            owners.remove(owner)
        }
    }

    fun release(owner: String) {
        owners.remove(owner)
        if (owners.isEmpty()) {
            try {
                mgr?.removeUpdates(listener)
            } catch (_: Exception) {
            }
            speedKmh = 0.0
            lastLoc = null
        }
    }

    fun tripElapsedMs(now: Long): Long =
        tripAccumMs + if (tripState == TripState.RUNNING) now - tripResumeMs else 0L

    fun startTrip(ctx: Context, bikeId: String?) {
        val now = System.currentTimeMillis()
        tripBikeId = bikeId
        tripDistanceM = 0.0
        tripAccumMs = 0L
        tripStartMs = now
        tripResumeMs = now
        lastLoc = null
        tripState = TripState.RUNNING
        ContextCompat.startForegroundService(ctx, Intent(ctx, TrackingService::class.java))
    }

    fun pauseTrip() {
        if (tripState != TripState.RUNNING) return
        tripAccumMs += System.currentTimeMillis() - tripResumeMs
        tripState = TripState.PAUSED
    }

    fun resumeTrip() {
        if (tripState != TripState.PAUSED) return
        tripResumeMs = System.currentTimeMillis()
        lastLoc = null
        tripState = TripState.RUNNING
    }

    /** Finaliza e grava a viagem. Devolve a viagem gravada (ou null se não havia viagem). */
    fun finishTrip(ctx: Context): Trip? {
        if (tripState == TripState.IDLE) return null
        val now = System.currentTimeMillis()
        val dur = tripElapsedMs(now)
        val km = tripDistanceM / 1000.0
        val avg = if (dur > 0) km / (dur / 3600000.0) else 0.0
        val trip = Trip(newId(), tripBikeId, tripStartMs, dur, tripDistanceM, avg)
        Repo.addTrip(trip)
        Repo.addOdometer(tripBikeId, km)
        tripState = TripState.IDLE
        tripDistanceM = 0.0
        tripAccumMs = 0L
        ctx.stopService(Intent(ctx, TrackingService::class.java))
        return trip
    }
}

/** Serviço em primeiro plano: mantém o GPS ativo mesmo com o Google Maps/Waze aberto. */
class TrackingService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Perm.refresh(this)
        if (!Perm.granted) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("trip", "Viagem em andamento", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n: Notification = NotificationCompat.Builder(this, "trip")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Garagem Moto")
            .setContentText("Registrando sua viagem por GPS")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        LocationEngine.acquire(this, "trip")
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        LocationEngine.release("trip")
        super.onDestroy()
    }
}
