package br.com.garagemmoto

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class CatalogBike(
    val id: String,
    val brand: String,
    val model: String,
    val year: Int,
    val category: String,
    val version: String,
    val photo: String?,          // caminho em assets/, ou null se a foto está pendente
    val wheels: FloatArray?,     // [fx, fy, fr, rx, ry, rr] em frações da imagem (opcional)
    val status: String,          // "pendente" ou "ok"
)

data class Bike(
    val id: String,
    val catalogId: String?,
    val name: String,
    val year: Int,
    val customPhoto: String?,
    val odometerKm: Double,
)

data class Trip(
    val id: String,
    val bikeId: String?,
    val startMs: Long,
    val durationMs: Long,
    val distanceM: Double,
    val avgKmh: Double,
)

data class Fill(
    val id: String,
    val bikeId: String,
    val dateMs: Long,
    val odometerKm: Double,
    val liters: Double,
    val pricePerLiter: Double,
    val full: Boolean,
)

data class Reminder(
    val id: String,
    val bikeId: String,
    val type: String,
    val everyDays: Int?,
    val everyKm: Int?,
    val lastDateMs: Long,
    val lastKm: Double,
)

data class AppSettings(
    val mapApp: String = "google",      // "google" | "waze"
    val musicPkg: String? = null,       // null = perguntar
    val theme: String = "auto",         // "auto" | "dia" | "noite"
    val motion: Boolean = true,
    val selectedBikeId: String? = null,
)

private fun JSONObject.str(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null
private fun JSONObject.int(k: String): Int? = if (has(k) && !isNull(k)) getInt(k) else null

object Repo {
    private var file: File? = null

    var bikes by mutableStateOf(listOf<Bike>())
        private set
    var trips by mutableStateOf(listOf<Trip>())
        private set
    var fills by mutableStateOf(listOf<Fill>())
        private set
    var reminders by mutableStateOf(listOf<Reminder>())
        private set
    var favorites by mutableStateOf(setOf<String>())
        private set
    var settings by mutableStateOf(AppSettings())
        private set

    fun init(ctx: Context) {
        if (file != null) return
        file = File(ctx.filesDir, "garagem_moto.json")
        load()
    }

    fun selectedBike(): Bike? =
        bikes.firstOrNull { it.id == settings.selectedBikeId } ?: bikes.firstOrNull()

    // ---------- mutações ----------
    fun addBike(b: Bike) {
        bikes = bikes + b
        if (settings.selectedBikeId == null || bikes.size == 1) settings = settings.copy(selectedBikeId = b.id)
        save()
    }

    fun updateBike(b: Bike) {
        bikes = bikes.map { if (it.id == b.id) b else it }
        save()
    }

    fun removeBike(id: String) {
        bikes = bikes.filter { it.id != id }
        fills = fills.filter { it.bikeId != id }
        reminders = reminders.filter { it.bikeId != id }
        if (settings.selectedBikeId == id) settings = settings.copy(selectedBikeId = bikes.firstOrNull()?.id)
        save()
    }

    fun addOdometer(bikeId: String?, km: Double) {
        val b = bikes.firstOrNull { it.id == bikeId } ?: return
        updateBike(b.copy(odometerKm = b.odometerKm + km))
    }

    fun setSettings(s: AppSettings) {
        settings = s
        save()
    }

    fun toggleFavorite(catalogId: String) {
        favorites = if (catalogId in favorites) favorites - catalogId else favorites + catalogId
        save()
    }

    fun addTrip(t: Trip) {
        trips = listOf(t) + trips
        save()
    }

    fun deleteTrip(id: String) {
        trips = trips.filter { it.id != id }
        save()
    }

    fun addFill(f: Fill) {
        fills = fills + f
        val b = bikes.firstOrNull { it.id == f.bikeId }
        if (b != null && f.odometerKm > b.odometerKm) updateBike(b.copy(odometerKm = f.odometerKm))
        save()
    }

    fun deleteFill(id: String) {
        fills = fills.filter { it.id != id }
        save()
    }

    fun addReminder(r: Reminder) {
        reminders = reminders + r
        save()
    }

    fun updateReminder(r: Reminder) {
        reminders = reminders.map { if (it.id == r.id) r else it }
        save()
    }

    fun deleteReminder(id: String) {
        reminders = reminders.filter { it.id != id }
        save()
    }

    // ---------- persistência ----------
    private fun save() {
        try {
            file?.writeText(toJson().toString())
        } catch (_: Exception) {
        }
    }

    private fun load() {
        val f = file ?: return
        if (!f.exists()) return
        try {
            val o = JSONObject(f.readText())
            bikes = o.optJSONArray("bikes").mapObjs {
                Bike(it.getString("id"), it.str("catalogId"), it.getString("name"), it.optInt("year", 0),
                    it.str("customPhoto"), it.optDouble("odometerKm", 0.0))
            }
            trips = o.optJSONArray("trips").mapObjs {
                Trip(it.getString("id"), it.str("bikeId"), it.getLong("startMs"), it.getLong("durationMs"),
                    it.getDouble("distanceM"), it.getDouble("avgKmh"))
            }
            fills = o.optJSONArray("fills").mapObjs {
                Fill(it.getString("id"), it.getString("bikeId"), it.getLong("dateMs"), it.getDouble("odometerKm"),
                    it.getDouble("liters"), it.getDouble("pricePerLiter"), it.optBoolean("full", true))
            }
            reminders = o.optJSONArray("reminders").mapObjs {
                Reminder(it.getString("id"), it.getString("bikeId"), it.getString("type"), it.int("everyDays"),
                    it.int("everyKm"), it.getLong("lastDateMs"), it.getDouble("lastKm"))
            }
            val fav = o.optJSONArray("favorites")
            favorites = if (fav == null) emptySet() else (0 until fav.length()).map { fav.getString(it) }.toSet()
            val s = o.optJSONObject("settings")
            if (s != null) {
                settings = AppSettings(
                    s.optString("mapApp", "google"), s.str("musicPkg"), s.optString("theme", "auto"),
                    s.optBoolean("motion", true), s.str("selectedBikeId"),
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun <T> JSONArray?.mapObjs(f: (JSONObject) -> T): List<T> {
        if (this == null) return emptyList()
        val l = ArrayList<T>()
        for (i in 0 until length()) l.add(f(getJSONObject(i)))
        return l
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("versao", 1)
        o.put("bikes", JSONArray().also { a ->
            bikes.forEach {
                a.put(JSONObject().put("id", it.id).put("catalogId", it.catalogId).put("name", it.name)
                    .put("year", it.year).put("customPhoto", it.customPhoto).put("odometerKm", it.odometerKm))
            }
        })
        o.put("trips", JSONArray().also { a ->
            trips.forEach {
                a.put(JSONObject().put("id", it.id).put("bikeId", it.bikeId).put("startMs", it.startMs)
                    .put("durationMs", it.durationMs).put("distanceM", it.distanceM).put("avgKmh", it.avgKmh))
            }
        })
        o.put("fills", JSONArray().also { a ->
            fills.forEach {
                a.put(JSONObject().put("id", it.id).put("bikeId", it.bikeId).put("dateMs", it.dateMs)
                    .put("odometerKm", it.odometerKm).put("liters", it.liters)
                    .put("pricePerLiter", it.pricePerLiter).put("full", it.full))
            }
        })
        o.put("reminders", JSONArray().also { a ->
            reminders.forEach {
                a.put(JSONObject().put("id", it.id).put("bikeId", it.bikeId).put("type", it.type)
                    .put("everyDays", it.everyDays).put("everyKm", it.everyKm)
                    .put("lastDateMs", it.lastDateMs).put("lastKm", it.lastKm))
            }
        })
        o.put("favorites", JSONArray(favorites.toList()))
        o.put("settings", JSONObject().put("mapApp", settings.mapApp).put("musicPkg", settings.musicPkg)
            .put("theme", settings.theme).put("motion", settings.motion)
            .put("selectedBikeId", settings.selectedBikeId))
        return o
    }

    fun exportJson(): String = toJson().toString(2)

    private fun bikeName(id: String?): String = bikes.firstOrNull { it.id == id }?.name ?: ""

    private fun csv(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun tripsCsv(): String {
        val sb = StringBuilder("moto;inicio;duracao;distancia_km;velocidade_media_kmh\n")
        trips.forEach {
            sb.append(csv(bikeName(it.bikeId))).append(';').append(dateFmt(it.startMs)).append(';')
                .append(durFmt(it.durationMs)).append(';').append(f2(it.distanceM / 1000.0)).append(';')
                .append(f1(it.avgKmh)).append('\n')
        }
        return sb.toString()
    }

    fun fillsCsv(): String {
        val sb = StringBuilder("moto;data;odometro_km;litros;preco_litro;tanque_cheio;total_reais\n")
        fills.sortedBy { it.dateMs }.forEach {
            sb.append(csv(bikeName(it.bikeId))).append(';').append(dateFmt(it.dateMs)).append(';')
                .append(f1(it.odometerKm)).append(';').append(f2(it.liters)).append(';')
                .append(f2(it.pricePerLiter)).append(';').append(if (it.full) "sim" else "nao").append(';')
                .append(f2(it.liters * it.pricePerLiter)).append('\n')
        }
        return sb.toString()
    }
}
