package br.com.garagemmoto

import android.content.Context
import org.json.JSONArray

object Catalog {
    var items: List<CatalogBike> = emptyList()
        private set

    fun load(ctx: Context) {
        if (items.isNotEmpty()) return
        try {
            val txt = ctx.assets.open("catalog.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(txt)
            val l = ArrayList<CatalogBike>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val w = o.optJSONArray("wheels")
                val wheels = if (w != null && w.length() == 6) FloatArray(6) { w.getDouble(it).toFloat() } else null
                l.add(
                    CatalogBike(
                        id = o.getString("id"),
                        brand = o.getString("brand"),
                        model = o.getString("model"),
                        year = o.getInt("year"),
                        category = o.getString("category"),
                        version = o.optString("version", ""),
                        photo = if (o.isNull("photo")) null else o.getString("photo"),
                        wheels = wheels,
                        status = o.optString("status", "pendente"),
                    )
                )
            }
            items = l.sortedWith(compareBy({ it.brand }, { it.model }, { it.year }))
        } catch (_: Exception) {
        }
    }

    fun byId(id: String): CatalogBike? = items.firstOrNull { it.id == id }
}
