# Créditos de fotos — Garagem Moto

**Estado: ninguna foto incluida en esta versión.**

El catálogo (`app/src/main/assets/catalog.json`) tiene 34 modelos y los 34 están con
`"photo": null` y `"status": "pendente"`. Motivo: el entorno donde se generó el proyecto no tenía
acceso a internet, así que no fue posible descargar fotos, comprobar su licencia ni verificar que
correspondan al modelo y a la versión exactos. No se incluyó ninguna imagen de origen dudoso.

La lista de modelos pendientes está en `photos/PHOTOS-PENDING.csv`
(columnas `fonte`, `licenca` y `credito` vacías, listas para completar).

## Cómo agregar una foto con licencia

1. Busca una imagen con licencia que permita redistribución (por ejemplo CC0, CC BY o CC BY-SA en
   Wikimedia Commons, o una foto propia / con permiso escrito del fotógrafo o la marca).
2. Verifica que sea el modelo y la versión indicados en el catálogo (año, versión, color/carenado).
3. Recorta el fondo (PNG/WebP con transparencia), tres cuartos frontal, ~1400 px de ancho.
4. Copia el archivo a `app/src/main/assets/photos/<id>.webp`.
5. En `catalog.json`, para ese `id`: `"photo": "photos/<id>.webp"` y `"status": "ok"`.
   Opcional, para que las ruedas giren sobre la foto: `"wheels": [fx, fy, fr, rx, ry, rr]`
   (centro y radio de la rueda delantera y trasera, como fracción del ancho/alto de la imagen).
6. Registra abajo la fuente, la licencia y el crédito.

## Registro

| id | fuente (URL) | licencia | crédito / autor | modelo y versión verificados |
|----|--------------|----------|-----------------|------------------------------|
| _(vacío)_ | | | | |

Mientras un modelo siga pendiente, el usuario puede importar su propia foto en
**Minha Garagem → Importar foto**. Con foto propia solo se aplica el efecto de carretera.
Sin ninguna foto, el tablero muestra una ilustración de reserva con ruedas giratorias.
