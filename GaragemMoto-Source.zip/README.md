# Garagem Moto

Tablero Android nativo para motociclistas (Kotlin + Jetpack Compose). Interfaz en portugués de
Brasil, vertical y horizontal. Identificador de aplicación independiente: `br.com.garagemmoto`.
Identidad visual inspirada en Garagem TS-7 (panel oscuro, vehículo recortado, velocímetro GPS,
viaje y consumo, temas día/noche).

> **Estado honesto:** este código fue escrito sin poder compilarlo ni ejecutarlo (el entorno no
> tenía Android SDK, Gradle ni internet). **No está probado en ningún dispositivo ni emulador,
> ni en Android 15.** Es probable que el primer *Sync/Build* muestre algún error menor de
> compilación; ver "Qué falta" más abajo.

## Compilar

Requisitos: Android Studio Ladybug (2024.2) o más nuevo, JDK 17+ (el que trae Android Studio sirve),
internet en el primer build (descarga Gradle 8.9, AGP 8.7.3 y dependencias).

1. Android Studio → **Open** → carpeta `GaragemMoto/`.
2. Espera el *Gradle Sync*. Si pide instalar **Android SDK Platform 35**, acéptalo.
3. Conecta el teléfono con depuración USB (o crea un emulador Pixel con Android 15 / API 35) y pulsa **Run ▶**.
4. Para generar el APK: **Build → Build APK(s)**. Sale en
   `app/build/outputs/apk/debug/app-debug.apk` (renómbralo `GaragemMoto.apk`).
   Instálalo en el teléfono permitiendo "instalar apps desconocidas".

Por línea de comandos (con Gradle 8.9 instalado): `gradle assembleDebug`.
El `gradle-wrapper.jar` no se incluye (no se pudo generar sin internet); Android Studio lo regenera,
o ejecuta `gradle wrapper --gradle-version 8.9` una vez.

## Qué incluye

- **Tablero**: velocímetro GPS, distancia del viaje, consumo medio km/L; carretera en perspectiva
  y ruedas elípticas girando según la velocidad GPS; se detienen al parar o si el GPS no da fix
  durante 5 s. **Prévia da animação** (velocidad simulada 0–140 km/h) y interruptor de movimiento.
- **Botones**: Maps, Música, Viagem, Minha Garagem. Elección de Google Maps o Waze y del
  reproductor de música instalado (Ajustes). Tema Automático / Dia / Noite.
- **Catálogo**: 34 modelos, 8 marcas (Honda, Yamaha, Shineray, Bajaj, Royal Enfield, Kawasaki,
  Suzuki, BMW), por marca/modelo/año/categoría, búsqueda, filtros y favoritos.
- **Minha Garagem**: varias motos, elegir la del tablero, importar foto de la galería
  (Photo Picker, sin permisos; corrige rotación EXIF), odómetro editable.
- **Viagem**: iniciar / pausar / retomar / finalizar, con servicio en primer plano
  (tipo `location`) para seguir registrando con Maps/Waze abierto. Guarda fecha, duración,
  distancia y velocidad media (distancia / tiempo total, paradas incluidas).
- **Combustível**: odómetro, litros, precio; km/L entre dos llenados completos (los parciales
  intermedios suman litros) y R$/km; historial por moto; mensaje claro cuando faltan datos.
- **Lembretes**: aceite, revisión, cadena, neumáticos, por días y/o km; estado "faltan / atrasado".
- **Datos**: todo local (`filesDir/garagem_moto.json`), sin internet. Exportar JSON + 2 CSV.

## Qué falta o es limitado

| Tema | Situación |
|------|-----------|
| **Fotos reales con licencia** | **Pendiente.** 34/34 modelos sin foto (ver `photos/CREDITS.md` y `photos/PHOTOS-PENDING.csv`). Sin foto se usa una ilustración de reserva. |
| **Compilación y APK** | No compilado aquí. `GaragemMoto.apk` no se entrega. |
| **Pruebas en dispositivo** | Ninguna: ni selección de moto, importación de fotos, animación, permisos, viajes ni Android 15 / Moto G05. |
| **Datos del catálogo** | Año y versión de cada modelo son referencias de memoria, **no verificadas**; revísalos junto con cada foto. |
| **Rueda sobre foto** | Soportada vía `wheels` en `catalog.json`, pero sin fotos no hay anclas calibradas. |
| **Recordatorios** | Solo se ven dentro de la app; no hay notificaciones push programadas. |
| **Viaje activo** | Vive en memoria: si Android mata la app, el viaje en curso se pierde. |
| **Exportación** | Incluye datos, no los archivos de foto. Sin importar/restaurar un export. |
| **Google Maps/Waze** | Se abren como app; no se lee la ruta de ellos. El viaje usa el GPS propio. |

## Lista de pruebas (para hacer en el teléfono)

1. Primer arranque: permiso de ubicación precisa y notificaciones → "GPS ativo" al salir a la calle.
2. Catálogo → agregar una moto → Minha Garagem → seleccionarla → aparece en el tablero.
3. Importar foto de galería (también una vertical con rotación EXIF) → solo efecto de carretera.
4. Prévia da animação: sube/baja velocidad; con el interruptor de movimiento apagado todo se detiene.
5. Caminar/conducir: el velocímetro sigue el GPS; en un túnel o tapando la señal, vuelve a 0 y se detiene.
6. Viagem: iniciar → abrir Maps/Waze → volver → la distancia sigue creciendo → pausar → finalizar → aparece en el historial.
7. Girar el teléfono: panel horizontal sin perder estado.
8. Combustível: dos llenados completos → km/L y R$/km; con un solo llenado → mensaje de datos faltantes.
9. Lembretes: crear por km y por días; "Feito agora".
10. Ajustes → Exportar histórico → compartir JSON/CSV.
11. Modo avión: todo sigue funcionando.

## Obtener el APK sin instalar Android Studio (GitHub Actions)

1. Crea un repositorio privado en github.com y sube el contenido de esta carpeta (incluida `.github/`).
2. Pestaña **Actions** → "Build GaragemMoto.apk" → **Run workflow** (también corre solo en cada push).
3. Al terminar (unos 5–10 min), abre la ejecución → **Artifacts → GaragemMoto-apk** → descarga `GaragemMoto.apk`.
4. Si el build falla, copia el error del log y pásalo para corregir el código.
